// OrderItem interface (abstraction)
interface OrderItem {
    String getName();
    double getPrice();
    int getQuantity();
    double calculateTotal();
}

// Concrete implementation of OrderItem
class ConcreteOrderItem implements OrderItem {
    private String name;
    private double price;
    private int quantity;

    public ConcreteOrderItem(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public int getQuantity() {
        return quantity;
    }

    @Override
    public double calculateTotal() {
        return price * quantity;
    }
}
