
abstract class PaymentStrategy {
    abstract void pay();
}
