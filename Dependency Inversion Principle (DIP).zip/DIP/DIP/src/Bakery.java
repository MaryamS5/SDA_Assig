// Bakery class now extends Menu to inherit menu properties
public class Bakery extends Menu {

    // Constructor for Bakery item with ID
    public Bakery(int id, String name, double price) {
        super(id, name, price);
    }

    // Constructor for Bakery item with quantity
    public Bakery(int id, String name, double price, int quantity) {
        super(id, name, price, quantity);
    }

    // Useful for debugging or displaying bakery details
    @Override
    public String toString() {
        return super.toString();
    }
}

