// Step 1: Convert PaymentStrategy into an abstract class
abstract class PaymentStrategy {
    abstract void pay();
}
