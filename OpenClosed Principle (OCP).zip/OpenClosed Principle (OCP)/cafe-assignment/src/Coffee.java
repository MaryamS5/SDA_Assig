// Coffee class extends Menu to represent coffee items in JavaCafe
public class Coffee extends Menu {

    // Constructor for Coffee item with default quantity
    public Coffee(int id, String name, double price) {
        super(id, name, price, "Coffee");
    }

    // Constructor for Coffee item with specified quantity
    public Coffee(int id, String name, double price, int quantity) {
        super(id, name, price, quantity, "Coffee");
    }
}
