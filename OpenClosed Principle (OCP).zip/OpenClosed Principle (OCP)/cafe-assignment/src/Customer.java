import java.util.Scanner;

// Define interfaces for flexibility
interface IRatingService {
    void collectRating();
}

interface IPaymentService {
    void processPayment();
}

// Concrete implementations (can be extended without modifying Customer)
class DefaultRatingService implements IRatingService {
    public void collectRating() {
        System.out.println("Collecting rating from the customer...");
    }
}

class DefaultPaymentService implements IPaymentService {
    public void processPayment() {
        System.out.println("Processing payment...");
    }
}

// Customer class now depends on abstractions
public class Customer implements staff {
    private final IRatingService ratingService;
    private final IPaymentService paymentService;

    // Constructor accepts implementations, ensuring flexibility
    public Customer(IRatingService ratingService, IPaymentService paymentService) {
        this.ratingService = ratingService;
        this.paymentService = paymentService;
    }

    public void rateService() {
        ratingService.collectRating();
    }

    public void payOrder() {
        paymentService.processPayment();
    }
}
