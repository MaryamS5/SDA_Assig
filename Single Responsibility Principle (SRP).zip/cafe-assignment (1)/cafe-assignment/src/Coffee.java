// Coffee class now extends Menu to inherit menu properties
public class Coffee extends Menu {

    // Constructor for Coffee item with ID
    public Coffee(int id, String name, double price) {
        super(id, name, price);
    }

    // Constructor for Coffee item with quantity
    public Coffee(int id, String name, double price, int quantity) {
        super(id, name, price, quantity);
    }

    // Useful for debugging or displaying coffee details
    @Override
    public String toString() {
        return super.toString();
    }
}
