
import java.util.ArrayList;

public class MenuDisplay {
    public void displayMenu(ArrayList<Menu> products) {
        System.out.println("********* Menu *********");
        System.out.println("ID    NAME      PRICE");
        for (Menu type : products) {
            System.out.println(type.getId() + "     " + type.getName() + "     " + type.getPrice());
        }
    }
}
