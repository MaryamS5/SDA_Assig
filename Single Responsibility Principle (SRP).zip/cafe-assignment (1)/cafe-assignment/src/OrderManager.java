import java.util.ArrayList;
import java.util.List;

class OrderManager {
    private List<OrderItem> orderList = new ArrayList<>();

    public void addOrderItem(String name, double price, int quantity) {
        orderList.add(new OrderItem(name, price, quantity));
    }

    public List<OrderItem> getOrderList() {
        return orderList;
    }

    public void clearOrder() {
        orderList.clear();
    }

    public void displayOrder() {
        if (orderList.isEmpty()) {
            System.out.println("No items in the order.");
            return;
        }
        System.out.println("\nCurrent Order:");
        int id = 1;
        for (OrderItem item : orderList) {
            System.out.printf("%d. %s - %.2f SAR (Qty: %d)%n", id++, item.getName(), item.getPrice(), item.getQuantity());
        }
    }

    public boolean isOrderEmpty() {
        return orderList.isEmpty();
    }

    public void removeOrderItem(int index) {
        if (index >= 0 && index < orderList.size()) {
            orderList.remove(index);
        }
    }
}
