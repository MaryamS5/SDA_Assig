
import java.util.Scanner;

public class RatingService {
    private final Scanner input = new Scanner(System.in);

    public void collectRating() {
        int rate;
        while (true) {
            System.out.println("How do you rate our customer service?");
            System.out.println("[1] Excellent  [2] Average  [3] Poor");
            System.out.print("Choice: ");
            rate = input.nextInt();

            if (rate >= 1 && rate <= 3) {
                System.out.println("Thanks for rating, this will help us improve our service.");
                break;
            } else {
                System.out.println("Invalid choice, please try again.");
            }
        }
    }
}
