

import java.awt.Menu;
import java.util.Scanner;

public class Items extends Menu {
    private int calories;
    private String type, origin;

    public Items() {} // No-arg Constructor

    public Items(String name, String type, int calories) {
        super(name);
        this.type = type;
        this.calories = calories;
    }

    public Items(int calories, String origin, String name) {
        super(name);
        this.calories = calories;
        this.origin = origin;
    }

    public int getCalories() {
        return calories;
    }

    public String getType() {
        return type;
    }

    public String getOrigin() {
        return origin;
    }

    // Method to retrieve product details
    private static Items getProductInfo(int id) {
        return switch (id) {
            case 1 -> new Items(197, "Yemen", "Mocha");
            case 2 -> new Items(206, "Italy", "Latte");
            case 3 -> new Items(2, "South Africa", "Black");
            case 4 -> new Items("Bagel", "Plain", 250);
            case 5 -> new Items("Bread", "Rye Bread", 67);
            case 6 -> new Items("Donut", "Classic", 190);
            default -> null;
        };
    }

    // Method to display product info
    public void productInfo() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter product ID: ");
        int id = input.nextInt();

        Items item = getProductInfo(id);

        if (item == null) {
            System.out.println("Invalid Number, Try Again!!");
            return;
        }

        System.out.println("\n********************* Product Info *********************");
        System.out.println("Name: " + item.getName());

        if (item.getOrigin() != null) {
            System.out.println("Place of Origin: " + item.getOrigin());
        }
        if (item.getType() != null) {
            System.out.println("Type: " + item.getType());
        }
        System.out.println("Calories: " + item.getCalories());

        System.out.println("Description: " + switch (id) {
            case 1 -> "Shot of espresso combined with chocolate powder or syrup, followed by milk or cream. A variant of a latte.";
            case 2 -> "One or two shots of espresso, lots of steamed milk, and a thin layer of frothed milk.";
            case 3 -> "Coffee with no milk, milk substitute, or cream added.";
            case 4 -> "Classic soft, chewy, thick New York–style bagel.";
            case 5 -> "Fresh bread made with rye flour served with chocolate or butter.";
            case 6 -> "Shaped yeast-leavened roll with a crisp, shiny crust and a dense interior.";
            default -> "";
        });
    }
}
