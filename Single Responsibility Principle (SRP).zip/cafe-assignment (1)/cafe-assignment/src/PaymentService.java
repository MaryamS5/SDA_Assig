
import java.util.Scanner;

public class PaymentService {
    private final Scanner input = new Scanner(System.in);

    public void processPayment() {
        int choice;
        while (true) {
            System.out.println("[1] Pay for Order  [2] Back");
            System.out.print("Choice: ");
            choice = input.nextInt();

            if (choice == 1) {
                confirmPayment();
                break;
            } else if (choice == 2) {
                System.out.println("Returning to main menu...");
                break;
            } else {
                System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private void confirmPayment() {
        int paymentStatus;
        while (true) {
            System.out.println("Was your payment successful?");
            System.out.println("[1] Yes  [2] No");
            System.out.print("Choice: ");
            paymentStatus = input.nextInt();

            if (paymentStatus == 1) {
                System.out.println("Thanks for purchasing.");
                break;
            } else if (paymentStatus == 2) {
                System.out.println("Unsuccessful payment, please try again.");
            } else {
                System.out.println("Invalid choice, please try again.");
            }
        }
    }
}
